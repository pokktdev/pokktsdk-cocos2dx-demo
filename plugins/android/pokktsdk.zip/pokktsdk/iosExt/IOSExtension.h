#ifndef Cocos2dxV2xPlugin_IOSExtension_h
#define Cocos2dxV2xPlugin_IOSExtension_h

void notifyIOS(const char* operation, const char* param);
const char* getSDKVersionOnIOS();

#endif
