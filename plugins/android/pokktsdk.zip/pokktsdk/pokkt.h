#ifndef pokkt_h
#define pokkt_h

#include "common/PCPokktAds.h"
#include "common/PCPokktConfig.h"
#include "common/PCAdConfig.h"
#include "common/IAPDetails.h"
#include "common/PCEnums.h"

#endif /* pokkt_h */
