#ifndef PCPokktConfig_h
#define PCPokktConfig_h

#include <string>


namespace pokkt
{
    class PCPokktConfig
    {
    public:
        // common
        std::string applicationId;
        std::string securityKey;
    };
}

#endif /* PCPokktConfig_h */
