//
//  PCPokktAds.cpp
//  Cocos2dxV3xPlugin
//
//  Created by Pokkt on 27/01/17.
//
//

#include "PCPokktAds.h"
#include <string>
#include <sstream>
#include "../cajun/json/writer.h"
#include "../cajun/json/reader.h"
#include "../cajun/json/elements.h"


#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

#include "../androidExt/PCAndroidExtension.h"

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#include "IOSExtension.h"

#endif

using namespace pokkt;

std::map<std::string, PCPokktAds::ListenerTargetPairAdEvent*> PCPokktAds::_eventMapAdEvent;

// to_string() helper
template<typename T>
std::string to_string(const T& t)
{
    std::ostringstream os;
    os << t;
    return os.str();
}

void PCPokktAds::setPokktConfigWithAppId(std::string appID, std::string secKey)
{
    json::Object jsonObject;
    
    jsonObject["appId"] = json::String(appID);
    jsonObject["securityKey"] = json::String(secKey);
    
    std::stringstream strStream;
    json::Writer::Write(jsonObject, strStream);
    notifyNative(SET_POKKTADS_CONFIG, strStream.str().c_str());
    
    //notifyIOS(SET_POKKTADS_CONFIG, strStream.str().c_str());
}

void PCPokktAds::setTrackIAP(IAPDetails iapDetails)
{
    json::Object jsonObject;
    
    jsonObject["currencyCode"] = json::String(iapDetails.currencyCode);
    jsonObject["description"] = json::String(iapDetails.description);
    jsonObject["productId"] = json::String(iapDetails.productId);
    jsonObject["price"] = json::String(to_string(iapDetails.price));
    jsonObject["title"] = json::String(iapDetails.title);
    
    std::stringstream strStream;
    json::Writer::Write(jsonObject, strStream);
    notifyNative(SET_POKKTADS_CONFIG, strStream.str().c_str());
}

void PCPokktAds::setAnalyticDetail(PCPokktAnalyticsDetail analyticDetail)
{
    json::Object jsonObject;
    
    jsonObject["googleAnalyticsID"] = json::String(analyticDetail.googleTrackerID);
    jsonObject["mixPanelProjectToken"] = json::String(analyticDetail.mixPanelTrackerID);
    jsonObject["flurryApplicationKey"] = json::String(analyticDetail.flurryTrackerID);
    jsonObject["selectedAnalyticsType"] = json::String(analyticDetail.eventType);
    
    std::stringstream strStream;
    json::Writer::Write(jsonObject, strStream);
    notifyNative(ANALYTICS_SET_DETAILS, strStream.str().c_str());
    
}

void PCPokktAds::initWithBannerAdSize(std::string screenName, int width, int height, int x, int y)
{
    json::Object jsonObject;
    jsonObject["screenName"] = json::String(screenName);
    jsonObject["width"] = json::String(to_string(width));
    jsonObject["height"] = json::String(to_string(height));
    
    jsonObject["x"] = json::String(to_string(x));
    jsonObject["y"] = json::String(to_string(y));

    
    std::stringstream strStream;
    json::Writer::Write(jsonObject, strStream);
    notifyNative(BANNER_LOAD_WITH_RECT_OP, strStream.str().c_str());
    
}

void PCPokktAds::loadBanner(std::string screenName, int position)
{
    json::Object jsonObject;
    jsonObject["screenName"] = json::String(screenName);
    jsonObject["bannerPosition"] = json::String(to_string(position));
    
    std::stringstream strStream;
    json::Writer::Write(jsonObject, strStream);
    notifyNative(BANNER_LOAD, strStream.str().c_str());
}
void PCPokktAds::handleNativeMessage(std::string operation, std::string param)
{
    POKKTLOG("[POKKT-CPP] message received! operation: %s, param: %s", operation.c_str(), param.c_str());
    
    // filter ad-events
    if ((operation.compare(AD_CACHING_COMPLETED_EVENT) == 0) ||
        (operation.compare(AD_CACHING_FAILED_EVENT) == 0) ||
        (operation.compare(AD_CLOSED_EVENT) == 0) ||
        (operation.compare(AD_COMPLETED_EVENT) == 0) ||
        (operation.compare(AD_DISPLAYED_EVENT) == 0) ||
        (operation.compare(AD_SKIPPED_EVENT) == 0) ||
        (operation.compare(AD_GRATIFIED_EVENT) == 0) ||
        (operation.compare(AD_AVAILABILITY_EVENT) == 0) ||
        (operation.compare(AD_FAILED_TO_SHOW_EVENT) == 0))
    {
        ListenerTargetPairAdEvent* l = _eventMapAdEvent[operation];
        if (l != NULL)
        {
            EVT_SELECTOR_ADS_EVENT listener = l->listener;
            cocos2d::CCObject *target = l->target;
            json::Object jsonObject;
            std::stringstream strStream;
            strStream << param;
            json::Reader::Read(jsonObject, strStream);
            
            json::String& isRewarded = jsonObject["IS_REWARDED"];
            bool isReady = isRewarded.Value().compare("true") == 0;
            
            json::String& screenName = jsonObject["SCREEN_NAME"];
            screenName = jsonObject["SCREEN_NAME"];
            std::string screen = screenName.Value();
            
            json::String& rewardPoint = jsonObject["REWARD"];
            rewardPoint = jsonObject["REWARD"];
            std::string reward = rewardPoint.Value();
            
            (target->*listener)(screen, isReady, reward);
        }
        return;
    }
    else if (operation.compare(BANNER_LOADED_OP) == 0)
    {
        ListenerTargetPairAdEvent* l = _eventMapAdEvent[operation];
        if (l != NULL)
        {
            EVT_SELECTOR_ADS_EVENT listener = l->listener;
            cocos2d::CCObject *target = l->target;
            json::Object jsonObject;
            (target->*listener)(param, true, param);
        }
    }
    else if (operation.compare(BANNER_LOAD_FAILED_OP) == 0)
    {
        ListenerTargetPairAdEvent* l = _eventMapAdEvent[operation];
        if (l != NULL)
        {
            EVT_SELECTOR_ADS_EVENT listener = l->listener;
            cocos2d::CCObject *target = l->target;
            json::Object jsonObject;
            
            std::stringstream strStream;
            strStream << param;
            json::Reader::Read(jsonObject, strStream);
                        
            json::String& screenName = jsonObject["screenName"];
            screenName = jsonObject["screenName"];
            std::string screen = screenName.Value();
            
            json::String& errorMessage = jsonObject["errorMessage"];
            errorMessage = jsonObject["errorMessage"];
            std::string errMsg = errorMessage.Value();


            (target->*listener)(screen, false, errMsg);
        }
    }
    
}

void PCPokktAds::setAdEventListener(std::string eventName, EVT_SELECTOR_ADS_EVENT listener, cocos2d::CCObject *target)
{
    ListenerTargetPairAdEvent* pair = new ListenerTargetPairAdEvent();
    pair->listener = listener;
    pair->target = target;
    _eventMapAdEvent[eventName] = pair;
}

void PCPokktAds::removeAdEventListener(std::string eventName)
{
    CC_SAFE_DELETE(_eventMapAdEvent[eventName]);
    _eventMapAdEvent[eventName] = NULL;
}

void PCPokktAds::notifyNative(std::string operation, std::string param)
{
    POKKTLOG("[POKKT-CPP] notifying native of operation: %s", operation.c_str());
    
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    
    notifyAndroid(operation, param);
    
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    
    notifyIOS(operation.c_str(), param.c_str());
    
#endif
}

std::string PCPokktAds::getSDKVersionOnNative()
{
    POKKTLOG("[POKKT-CPP] getting sdk version on native...");
    
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    
    return getSDKVersionOnAndroid();
    
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    
    return getSDKVersionOnIOS();
    
#endif
    return "";
}




