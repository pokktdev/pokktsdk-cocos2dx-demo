#ifndef PCParser_h
#define PCParser_h

#include <map>
#include "PCPokktConfig.h"
#include "PCAdConfig.h"
#include "IAPDetails.h"
//#include "PCPokktManager.h"
//#include "PCPokktAds.h"
#include "../cajun/json/writer.h"
#include "../cajun/json/reader.h"
#include "../cajun/json/elements.h"

using namespace pokkt;


std::string toAdConfigJSONString(PCAdConfig* adConfig);
PCAdConfig* fromAdConfigJsonString(std::string param, std::map<std::string, std::string> &extraValues);
std::string toIAPDetailsJSONString(IAPDetails* config);
std::string toPokktConfigJSONString(PCPokktConfig* details);
std::string toBannerParamsJSONString(std::string screenName, int bannerPosition);
std::string toBannerRectParamsJSONString(std::string screenName,  int width, int height, int x, int y);

#endif /* PCParser_h */
