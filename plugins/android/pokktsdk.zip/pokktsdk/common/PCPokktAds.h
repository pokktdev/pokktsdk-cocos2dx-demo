#ifndef PCPokktAds_h
#define PCPokktAds_h

#include <stdio.h>
#include "cocos2d.h"
#include "PCPokktConfig.h"
#include "PCAdConfig.h"
#include "IAPDetails.h"
#include "PCEnums.h"
#include "PCPokktAnalyticsDetails.h"

namespace pokkt
{
#define POKKTLOG(format, ...) cocos2d::log(format, ##__VA_ARGS__)
    
    
    typedef void (cocos2d::CCObject::*EVT_SELECTOR_ADS_EVENT)(std::string, bool, std::string);
#define PC_ADS_EVENT_SELECTOR(_SELECTOR) (EVT_SELECTOR_ADS_EVENT)(&_SELECTOR)
    
    typedef void (cocos2d::CCObject::*EVT_SELECTOR_BANNER)(std::string, std::string);
#define PC_BANNER_EVENT_SELECTOR(_SELECTOR) (EVT_SELECTOR_BANNER)(&_SELECTOR) 
    
    class PCPokktAds
    {
    public:
        
        // pokkt standard APIs
        inline static void setDebug(bool value) { notifyNative(SET_DEBUG_OP, value ? "true" : "false"); }
        inline static void exportLog() { notifyNative(EXPORT_LOG_OP); }
        inline static void showToast(std::string message) { notifyNative(SHOW_TOAST_OP, message); }
        inline static void printLog(std::string message) { notifyNative(PRINT_LOG_OP, message); }
        
        inline static void setThirdPartyID(std::string thirdPartyId) { notifyNative(SET_THIRDPARTY_ID, thirdPartyId); }
 
        inline static std::string getSDKVersion() { return getSDKVersionOnNative(); }
                
        // Video ads related APIs
        
        inline static void cacheRewardedVideoAd(std::string message) { notifyNative(VIDEO_ADS_CACHE_REWARDED, message); }
        
        inline static void showRewardedVideoAd(std::string message) { notifyNative(VIDEO_SHOW_REWARDED_OP, message); }
        
        inline static void cacheNonRewardedVideoAd(std::string message) { notifyNative(VIDEO_CACHE_NONREWARDED_OP, message); }
        
        inline static void showNonRewardedVideoAd(std::string message) { notifyNative(VIDEO_SHOW_NONREWARDED_OP, message); }
        
        inline static void checkRewardedVideoAdAvailability(std::string message) { notifyNative(VIDEO_CHECK_REWARDED_AVAILABILITY_OP, message); }
        
        inline static void checkNonRewardedVideoAdAvailability(std::string message) { notifyNative(VIDEO_CHECK_NONOREWARDED_AVAILABILITY_OP, message); }
        
        //
        
        inline static void cacheRewardedInterstitialAd(std::string message) { notifyNative(INTERSTITIAL_CACHE_REWARDED_OP, message); }
        
        inline static void showRewardedInterstitialAd(std::string message) { notifyNative(INTERSTITIAL_SHOW_REWARDED_OP, message); }
        
        inline static void cacheNonRewardedInterstitialAd(std::string message) { notifyNative(INTERSTITIAL_CACHE_NONREWARDED_OP, message); }
        
        inline static void showNonRewardedInterstitialAd(std::string message) { notifyNative(INTERSTITIAL_SHOW_NONREWARDED_OP, message); }
        
        inline static void checkRewardedInterstitialAdAvailability(std::string message) { notifyNative(INTERSTITIAL_CHECK_REWARDED_AVAILABILITY_OP, message); }
        
        inline static void checkNonRewardedInterstitialAdAvailability(std::string message) { notifyNative(INTERSTITIAL_CHECK_NONREWARDED_AVAILABILITY_OP, message); }
        //
        
        static void initWithBannerAdSize(std::string screenName, int width, int height, int x, int y);
        inline static void destroyBanner() { notifyNative(BANNER_DESTROY); }
        
        static void loadBanner(std::string screenName, int position);
        inline static void destroyBottomBanner() { notifyNative(BANNER_DESTROY_BOTTOM); }
        inline static void setBannerAutoRefresh(std::string isRefresh) { notifyNative(BANNER_SHOULD_AUTO_REFRESH, isRefresh); }
        // handle messages via native (java/obj-c)
        static void setPokktConfigWithAppId(std::string appID, std::string secKey);
        static void handleNativeMessage(std::string operation, std::string param);
        
        static void setTrackIAP(IAPDetails iapDetails);
        
        static void setAnalyticDetail(PCPokktAnalyticsDetail analyticDetail);
        
        // sets a listener for an event (only one listener per event
        static void setAdEventListener(std::string eventName, EVT_SELECTOR_ADS_EVENT listener, cocos2d::CCObject *target);
        static void removeAdEventListener(std::string eventName);
        
        
        ~PCPokktAds(){}
        
    private:
                
        typedef struct __listenerTargetPairAdEvent
        {
            EVT_SELECTOR_ADS_EVENT listener;
            cocos2d::CCObject *target;
        } ListenerTargetPairAdEvent;
        
        
        static std::map<std::string, ListenerTargetPairAdEvent*> _eventMapAdEvent;
       // static std::map<std::string, ListenerTargetPairBannerEvent*> _eventMapBannerEvent;
        
        // use this to notify native pokkt runtime
        static void notifyNative(std::string operation, std::string param = "");
        
        // use this to get the coin associated
        static double getRewardedAdVcOnNative(PCAdConfig* adConfig);
        
        // sdk version
        static std::string getSDKVersionOnNative();
    };
}

#endif /* PCPokktAds_h */
