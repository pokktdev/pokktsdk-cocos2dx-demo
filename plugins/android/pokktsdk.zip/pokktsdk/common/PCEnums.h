#ifndef PCEnums_h
#define PCEnums_h


namespace pokkt
{
    
    /**
     * integration types
     **/
#define POKKT_INTEGRATION_TYPE_ALL          "0"
#define POKKT_INTEGRATION_TYPE_OFFERWALL    "1"
#define POKKT_INTEGRATION_TYPE_AD           "2"
    
    
    /**
     * implemented analytics types
     **/
#define POKKT_ANALYTICS_TYPE_NONE               "NONE"
#define POKKT_ANALYTICS_TYPE_GOOGLE_ANALYTICS   "GOOGLE_ANALYTICS"
#define POKKT_ANALYTICS_TYPE_MIXPANEL           "MIXPANEL"
#define POKKT_ANALYTICS_TYPE_FLURRY             "FLURRY"
#define POKKT_ANALYTICS_TYPE_FABRIC             "FABRIC"
    
    
    /**
     * in-app purchase store types
     **/
#define POKKT_IAP_STORE_TYPE_NONE       "NONE"
#define POKKT_IAP_STORE_TYPE_GOOGLE     "GOOGLE"
#define POKKT_IAP_STORE_TYPE_IOS        "IOS"
#define POKKT_IAP_STORE_TYPE_AMAZON     "AMAZON"
    
    
    /**
     * various pokkt-operations
     **/
#define SET_DEBUG_OP                "Debugging.shouldDebug"
#define EXPORT_LOG_OP               "exportLog"
#define SHOW_TOAST_OP               "showToast"
#define SHOW_LOG_OP                 "showLog"
#define PRINT_LOG_OP                 "printLog"    
#define INIT_POKKT_OP               "initPokkt"
#define UPDATE_POKKT_CONFIG_OP      "updatePokktConfig"
    
#define START_SESSION_OP            "startSession"
#define END_SESSION_OP              "endSession"
#define NOTIFY_APP_INSTALL_OP       "notifyAppInstall"
#define TRACK_IAP_OP                "trackIAP"
    
#define GET_COINS_OP                "getCoins"
#define GET_PENDING_COINS_OP        "getPendingCoins"
#define CHECK_OFFERWALL_CAMPAIGN_OP "checkOfferWallCampaign"
 
////
#define SET_POKKTADS_CONFIG                         "setPokktConfig"
#define VIDEO_ADS_CACHE_REWARDED                  "VideoAd.cacheRewarded"
#define VIDEO_SHOW_REWARDED_OP                   "VideoAd.showRewarded"
#define VIDEO_CACHE_NONREWARDED_OP               "VideoAd.cacheNonRewarded"
#define VIDEO_SHOW_NONREWARDED_OP                "VideoAd.showNonRewarded"
#define VIDEO_CHECK_REWARDED_AVAILABILITY_OP     "VideoAd.checkAdAvailability.rewarded"
#define VIDEO_CHECK_NONOREWARDED_AVAILABILITY_OP "VideoAd.checkAdAvailability.nonRewarded"
    
#define INTERSTITIAL_CACHE_REWARDED_OP                  "Interstitial.cacheRewarded"
#define INTERSTITIAL_SHOW_REWARDED_OP                   "Interstitial.showRewarded"
#define INTERSTITIAL_CACHE_NONREWARDED_OP               "Interstitial.cacheNonRewarded"
#define INTERSTITIAL_SHOW_NONREWARDED_OP                "Interstitial.showNonRewarded"
#define INTERSTITIAL_CHECK_REWARDED_AVAILABILITY_OP     "Interstitial.checkAdAvailability.rewarded"
#define INTERSTITIAL_CHECK_NONREWARDED_AVAILABILITY_OP  "Interstitial.checkAdAvailability.nonRewarded"
    
/////
#define CACHE_AD_OP                 "cacheAd"
#define SHOW_AD_OP                  "showAd"
#define CHECK_AD_AVAILABILITY_OP    "checkAdAvailability"
    
#define LOAD_BANNER_OP              "loadBanner"
#define LOAD_BANNER_RECT_OP         "loadBannerRect"
#define BANNER_AUTO_REFRESH         "bannerAutoRefresh"
#define REMOVE_BANNER               "removeBanner"
#define BANNER_LOAD                 "Banner.loadBanner"
#define BANNER_DESTROY_BOTTOM       "Banner.destroyBanner"    
    
#define  BANNER_LOADED_OP                   "BannerLoaded"
#define  BANNER_LOAD_FAILED_OP              "BannerLoadFailed"
#define  BANNER_DESTROY                     "Banner.destroyBanner"
#define  BANNER_SHOULD_AUTO_REFRESH         "Banner.shouldAutoRefresh"  
    
#define  SET_THIRDPARTY_ID                  "setThirdPartyUserId"   
#define  ANALYTICS_TRACK_IAP                "Analytics.trackIAP"
#define  ANALYTICS_SET_DETAILS              "Analytics.setAnalyticsDetails"    
    
    
    
    /**
     * pokkt-to-framework events
     **/
#define POKKT_INITIALISED_EVENT             "PokktInitialised"
    
#define AD_CACHING_COMPLETED_EVENT          "AdCachingCompleted"
#define AD_CACHING_FAILED_EVENT             "AdCachingFailed"
#define AD_CLOSED_EVENT                     "AdClosed"
#define AD_COMPLETED_EVENT                  "AdCompleted"
#define AD_DISPLAYED_EVENT                  "AdDisplayed"
#define AD_SKIPPED_EVENT                    "AdSkipped"
#define AD_GRATIFIED_EVENT                  "AdGratified"
#define AD_AVAILABILITY_EVENT               "AdAvailability"
#define AD_FAILED_TO_SHOW_EVENT             "AdFailedToShow"    
    
#define BANNER_LOADED_OP                       "BannerLoaded"
#define BANNER_LOAD_FAILED_OP                  "BannerLoadFailed"
#define BANNER_LOAD_WITH_RECT_OP               "Banner.loadBannerWithRect"    
    
#define COIN_RESPONSE_EVENT                 "CoinResponse"
#define COIN_RESPONSE_WITH_TRANS_ID_EVENT   "CoinResponseWithTransId"
#define COIN_RESPONSE_FAILED_EVENT          "CoinResponseFailed"
#define CAMPAIGN_AVAILABILITY_EVENT         "CampaignAvailability"
#define OFFERWALL_CLOSED_EVENT              "OfferwallClosed"
    
    
    /**
     * parameters name
     **/
    
#define REWARD              "REWARD"
#define BACK_PRESSED        "BACK_BUTTON"
#define FAIL_MESSAGE        "MESSAGE"
#define AD_VC               "AD_VC"
#define IS_AVAILABLE        "IS_AVAILABLE"
#define IS_READY            "IS_READY"
    
    
#define TOP_LEFT       1
#define TOP_CENTER     2
#define TOP_RIGHT      3
#define MIDDLE_LEFT    4
#define MIDDLE_CENTER  5
#define MIDDLE_RIGHT   6
#define BOTTOM_LEFT    7
#define BOTTOM_CENTER  8
#define BOTTOM_RIGHT   9
    
#define VIDEO_1             0
#define BANNER_1            1
#define INTERSTITIAL_1      3
}

#endif /* PCEnums_h */
