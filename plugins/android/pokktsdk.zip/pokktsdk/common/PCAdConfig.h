#ifndef PCAdConfig_h
#define PCAdConfig_h

#include <stdio.h>


namespace pokkt
{
    class PCAdConfig
    {
    public:
        std::string screenName;
        bool isRewarded;
        
        int adFormat;
        
        bool operator==(const PCAdConfig& adConfig)
        {
            return (screenName == adConfig.screenName && isRewarded == adConfig.isRewarded && adFormat == adConfig.adFormat);
        }
        
        PCAdConfig()
        {
            // default values
            screenName = "Default";
            adFormat = 0;
         }
    };
}

#endif /* PCAdConfig_h */
